# DON'T BLOCK ME! College Squad 3.0

A React 19 + Vite frontend for the College Squad quiz app, with Firebase Auth/Firestore support and local fallback mode.

## Run locally

1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and configure `VITE_FIREBASE_CONFIG` with your Firebase **web app** config JSON on one line, or inject the existing `__firebase_config` host global.
4. Run `npm run dev`.
5. Run `npm run build` to create `dist/`.

Do not put service-account private keys in frontend environment variables. Firebase web config is designed to be public; Firestore Security Rules must enforce authorization.

## Important security note

The app includes demo PIN behavior in client-side UI. A PIN embedded in frontend code is not secure authentication or authorization. Configure and test Firestore Security Rules before using real student or quiz data. No Firebase rules/configuration were included with the supplied source, so a production security audit of the backend is not possible from this frontend alone.

## Images

Remote images are optional enhancements. The card image component includes an error fallback; image URLs still depend on their third-party host being reachable.

## Verification

A production build should be checked with `npm install` and `npm run build`. The supplied environment could not complete dependency installation, so a successful build has not been verified here. Firebase multi-user behavior also requires a real Firebase project and rules.
